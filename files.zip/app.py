from flask import Flask, render_template_string, jsonify, request
from flask_cors import CORS
import requests
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# API Configuration
API_BASE_URL = "http://157.180.8.224:3000/address"

# HTML Template (embedded in Python)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Viewer</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .header h1 {
            font-size: 2em;
            margin-bottom: 10px;
        }

        .header p {
            opacity: 0.9;
            font-size: 0.95em;
        }

        .search-section {
            padding: 30px;
            background: #f8f9fa;
            border-bottom: 1px solid #e0e0e0;
        }

        .input-group {
            display: flex;
            gap: 10px;
            max-width: 800px;
            margin: 0 auto;
        }

        .input-wrapper {
            flex: 1;
            position: relative;
        }

        input[type="text"] {
            width: 100%;
            padding: 14px 20px;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-family: 'Courier New', monospace;
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        button {
            padding: 14px 30px;
            font-size: 16px;
            font-weight: 600;
            color: white;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        button:active {
            transform: translateY(0);
        }

        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .content {
            padding: 30px;
        }

        .loading {
            text-align: center;
            padding: 40px;
            color: #667eea;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .error {
            background: #fee;
            border-left: 4px solid #f44;
            padding: 20px;
            border-radius: 8px;
            color: #c33;
            margin: 20px 0;
        }

        .error-title {
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 1.1em;
        }

        .results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }

        .results-count {
            font-size: 1.2em;
            color: #333;
            font-weight: 600;
        }

        .transaction-card {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }

        .transaction-card:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }

        .tx-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f0f0;
        }

        .tx-hash {
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            color: #667eea;
            font-weight: 600;
            word-break: break-all;
            flex: 1;
            margin-right: 15px;
        }

        .tx-time {
            color: #666;
            font-size: 0.85em;
            white-space: nowrap;
        }

        .tx-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .detail-item {
            display: flex;
            flex-direction: column;
        }

        .detail-label {
            font-size: 0.8em;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .detail-value {
            font-size: 0.95em;
            color: #333;
            font-family: 'Courier New', monospace;
            word-break: break-all;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
        }

        .status-confirmed {
            background: #d4edda;
            color: #155724;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .no-results {
            text-align: center;
            padding: 60px 20px;
            color: #888;
        }

        .no-results-icon {
            font-size: 4em;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .json-viewer {
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            max-height: 300px;
            overflow: auto;
        }

        .json-content {
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            white-space: pre-wrap;
            word-break: break-all;
        }

        .toggle-json {
            background: #6c757d;
            padding: 8px 16px;
            font-size: 0.85em;
            margin-top: 10px;
        }

        @media (max-width: 768px) {
            .input-group {
                flex-direction: column;
            }

            .tx-header {
                flex-direction: column;
            }

            .tx-hash {
                margin-bottom: 10px;
                margin-right: 0;
            }

            .tx-details {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Transaction Viewer</h1>
            <p>Enter an address to view all associated transactions</p>
        </div>

        <div class="search-section">
            <div class="input-group">
                <div class="input-wrapper">
                    <input 
                        type="text" 
                        id="addressInput" 
                        placeholder="Enter blockchain address (e.g., 0x123...)" 
                        autocomplete="off"
                    />
                </div>
                <button id="searchBtn" onclick="fetchTransactions()">Search</button>
            </div>
        </div>

        <div class="content">
            <div id="results"></div>
        </div>
    </div>

    <script>
        // Use relative URL to call our backend
        const API_BASE_URL = '/api/address';
        
        // Allow Enter key to trigger search
        document.getElementById('addressInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                fetchTransactions();
            }
        });

        async function fetchTransactions() {
            const address = document.getElementById('addressInput').value.trim();
            const resultsDiv = document.getElementById('results');
            const searchBtn = document.getElementById('searchBtn');

            // Validation
            if (!address) {
                resultsDiv.innerHTML = `
                    <div class="error">
                        <div class="error-title">⚠️ Validation Error</div>
                        <div>Please enter a valid address</div>
                    </div>
                `;
                return;
            }

            // Show loading state
            searchBtn.disabled = true;
            searchBtn.textContent = 'Searching...';
            resultsDiv.innerHTML = `
                <div class="loading">
                    <div class="spinner"></div>
                    <div>Fetching transactions for address: <strong>${address}</strong></div>
                </div>
            `;

            try {
                const url = `${API_BASE_URL}/${address}/txs`;
                const response = await fetch(url);

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `HTTP Error: ${response.status}`);
                }

                const data = await response.json();
                displayResults(data, address);

            } catch (error) {
                resultsDiv.innerHTML = `
                    <div class="error">
                        <div class="error-title">❌ Error Fetching Data</div>
                        <div><strong>Message:</strong> ${error.message}</div>
                        <div style="margin-top: 10px; font-size: 0.9em;">
                            Please check:
                            <ul style="margin-left: 20px; margin-top: 5px;">
                                <li>The address is correct</li>
                                <li>The backend server is running</li>
                                <li>Your internet connection is working</li>
                            </ul>
                        </div>
                    </div>
                `;
            } finally {
                searchBtn.disabled = false;
                searchBtn.textContent = 'Search';
            }
        }

        function displayResults(data, address) {
            const resultsDiv = document.getElementById('results');

            // Check if data is an array
            const transactions = Array.isArray(data) ? data : (data.transactions || []);

            if (!transactions || transactions.length === 0) {
                resultsDiv.innerHTML = `
                    <div class="no-results">
                        <div class="no-results-icon">📭</div>
                        <h2>No Transactions Found</h2>
                        <p>No transactions were found for address: <strong>${address}</strong></p>
                    </div>
                `;
                return;
            }

            let html = `
                <div class="results-header">
                    <div class="results-count">
                        📊 Found ${transactions.length} transaction${transactions.length !== 1 ? 's' : ''}
                    </div>
                </div>
            `;

            transactions.forEach((tx, index) => {
                const txHash = tx.hash || tx.txHash || tx.id || 'N/A';
                const blockNumber = tx.blockNumber || tx.block || 'N/A';
                const timestamp = tx.timestamp || tx.time || 'N/A';
                const from = tx.from || tx.sender || 'N/A';
                const to = tx.to || tx.recipient || 'N/A';
                const value = tx.value || tx.amount || '0';
                const status = tx.status || 'confirmed';

                html += `
                    <div class="transaction-card">
                        <div class="tx-header">
                            <div class="tx-hash">
                                <strong>TX:</strong> ${txHash}
                            </div>
                            <div class="tx-time">
                                ${formatTimestamp(timestamp)}
                            </div>
                        </div>
                        <div class="tx-details">
                            <div class="detail-item">
                                <div class="detail-label">Block Number</div>
                                <div class="detail-value">${blockNumber}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">From</div>
                                <div class="detail-value">${from}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">To</div>
                                <div class="detail-value">${to}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Value</div>
                                <div class="detail-value">${value}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Status</div>
                                <div class="detail-value">
                                    <span class="status-badge status-${status.toLowerCase()}">
                                        ${status.toUpperCase()}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <button class="toggle-json" onclick="toggleJson(${index})">
                            View Raw JSON
                        </button>
                        <div id="json-${index}" class="json-viewer" style="display: none;">
                            <div class="json-content">${JSON.stringify(tx, null, 2)}</div>
                        </div>
                    </div>
                `;
            });

            resultsDiv.innerHTML = html;
        }

        function toggleJson(index) {
            const jsonDiv = document.getElementById(`json-${index}`);
            const isVisible = jsonDiv.style.display !== 'none';
            jsonDiv.style.display = isVisible ? 'none' : 'block';
            event.target.textContent = isVisible ? 'View Raw JSON' : 'Hide Raw JSON';
        }

        function formatTimestamp(timestamp) {
            if (!timestamp || timestamp === 'N/A') return 'N/A';
            
            // If timestamp is a number (Unix timestamp)
            if (typeof timestamp === 'number') {
                return new Date(timestamp * 1000).toLocaleString();
            }
            
            // If timestamp is already a date string
            const date = new Date(timestamp);
            if (!isNaN(date.getTime())) {
                return date.toLocaleString();
            }
            
            return timestamp;
        }

        // Focus on input on page load
        window.addEventListener('load', function() {
            document.getElementById('addressInput').focus();
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    """Serve the main HTML page"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/address/<address>/txs', methods=['GET'])
def get_transactions(address):
    """
    Proxy endpoint to fetch transactions from the external API
    """
    try:
        # Validate address (basic validation)
        if not address or len(address) < 10:
            return jsonify({
                'error': 'Invalid address format',
                'message': 'Please provide a valid blockchain address'
            }), 400

        # Make request to external API
        url = f"{API_BASE_URL}/{address}/txs"
        
        # Set a timeout to avoid hanging requests
        response = requests.get(url, timeout=30)
        
        # Check if request was successful
        response.raise_for_status()
        
        # Return the JSON data
        data = response.json()
        return jsonify(data), 200

    except requests.exceptions.Timeout:
        return jsonify({
            'error': 'Request timeout',
            'message': 'The external API took too long to respond'
        }), 504

    except requests.exceptions.ConnectionError:
        return jsonify({
            'error': 'Connection error',
            'message': 'Could not connect to the external API. Please check if the API is accessible.'
        }), 503

    except requests.exceptions.HTTPError as e:
        return jsonify({
            'error': 'HTTP error',
            'message': f'External API returned error: {e.response.status_code}',
            'details': str(e)
        }), e.response.status_code

    except requests.exceptions.RequestException as e:
        return jsonify({
            'error': 'Request failed',
            'message': 'An error occurred while fetching data',
            'details': str(e)
        }), 500

    except Exception as e:
        return jsonify({
            'error': 'Internal server error',
            'message': 'An unexpected error occurred',
            'details': str(e)
        }), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'api_base_url': API_BASE_URL
    }), 200

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Transaction Viewer Backend Server")
    print("=" * 60)
    print(f"📡 External API: {API_BASE_URL}")
    print(f"🌐 Server starting at: http://localhost:5000")
    print(f"🏥 Health check: http://localhost:5000/health")
    print("=" * 60)
    print("\nPress CTRL+C to stop the server\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
